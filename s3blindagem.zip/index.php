<?php

require('./themes/default/_theme.php');