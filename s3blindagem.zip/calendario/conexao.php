<?php
	$servidor = "mysql04.seguritysistem1.hospedagemdesites.ws";
	$usuario = "seguritysistem13";
	$senha = "adminti1*";
	$dbname = "seguritysistem13";
	
	//Criar a conexao
	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);