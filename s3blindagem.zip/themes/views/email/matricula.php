<?php $v->layout("_theme", ["title" => "Matricula Renovada com Sucesso"]); ?>

<h2>Seja bem-vindo(a) ao DflixControl <?= $nome ?> . Sua matricula foi renovada com sucesso?</h2>
<p>Aporveite todos os recursos de seu plano</p>
<p><a title='Confirmar Cadastro' href='##'>CLIQUE AQUI PARA CONFIRMAR</a></p>