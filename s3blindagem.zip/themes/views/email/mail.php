<?php $v->layout("_theme", ["" => ""]); ?>

<?= $message; ?>