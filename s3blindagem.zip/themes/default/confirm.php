<?php $v->layout("_theme"); ?>
<!-- Page Wrapper -->
<div style="background: url(https://i.postimg.cc/ZnHTP71s/aircraft-airplane-boat-1575833.jpg)" class="page-holder bg-cover">

  <div class="container py-5">
    <header class="text-center text-white py-5">
      <h1 class="display-4 font-weight-bold mb-4"><?= $titulo ?></h1>
      </br></br></br>
      <p class="lead mb-0"><?= $descricao ?></p>
      </br></br></br>
      <a href="<?= CONF_URL_BASE ?>/entrar"> <button class="btn btn-success"> Entrar </button> </a>
    </header>

   

  </div>
</div>

