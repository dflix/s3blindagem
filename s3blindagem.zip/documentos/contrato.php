
        <?php
        require '../vendor/autoload.php';
        
        $pagina = file_get_contents("".CONF_URL_BASE."/documentos/recibo.php");
        
        echo $pagina;
        ?>

