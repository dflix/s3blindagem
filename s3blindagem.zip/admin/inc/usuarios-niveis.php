
<div class="container-fluid"> 
    
     <div class="col-md-6" style="margin-top: 10px;"> 
            <a href="<?= CONF_URL_APP ?>/?p=usuarios-niveis" style="text-decoration: none;color:#fff;">  <div class="subscribe btn btn-primary btn-block rounded-pill shadow-sm"> Niveis </div> </a>
        </div>

        <div class="col-md-6" style="margin-top: 10px;"> 
            <a href="<?= CONF_URL_APP ?>/?p=usuarios" style="text-decoration: none;color:#fff;">   <div class="subscribe btn btn-primary btn-block rounded-pill shadow-sm"> usuarios</div> </a>
        </div>
    
    <div class="col-md-12 clear">Boa</div>
    
  
    
    <div class="row">
    
        <div class="col-md-6"> <h3> Niveis de Usuários </h3>
            <p>nivel 1 cliente | nivel 2 afiliado | nivel 3 master |nivel 4 master</p>
           
            <form>
            
            
        </div>
        <div class="col-md-6"> Usuarios Cadastados </div>
    
    </div>
    
</div>

